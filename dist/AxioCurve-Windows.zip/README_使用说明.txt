AxioCurve Windows 使用说明
=========================

AxioCurve 是一个用于科研曲线动画、双 y 轴绘图、多格式导出和 Fluent .out 转 CSV 的 MATLAB 桌面工具。

1. 如果电脑已安装 MATLAB Runtime R2024a：
   直接双击 AxioCurve.exe 即可运行。

2. 如果首次运行提示缺少 MATLAB Runtime：
   先双击 AxioCurve_RuntimeInstaller_web.exe，按提示安装运行环境；安装完成后再运行 AxioCurve.exe。

3. 基本使用流程：
   - 点击“选择数据文件”导入 CSV。
   - 在左侧数据表中勾选一个 X 列，可分别勾选 Y左 和 Y右 曲线。
   - 点击“静态预览”检查坐标轴、图例、颜色和字体。
   - 设置导出宽高、DPI、动画间隔和导出格式。
   - 点击“导出选定格式”输出 GIF、MP4、PNG 序列或静态图片。

4. 注意事项：
   - GIF/MP4/PNG序列会按照动画间隔抽帧。
   - PNG/JPG/TIF 单图会导出完整曲线。
   - 在“数据与导出”页底部的“Fluent .out 转 CSV”区域，可先选择一个或多个 .out 文件，再选择输出文件夹批量生成同名 CSV。
   - 转换区域会用浅橘色进度条显示进度，并在白色信息窗口逐行显示“已选择xxx文件”“成功：xxx.out转化为xxx.csv”等转换记录。
   - 软件会记住上一次 CSV 导入、图像导出、PNG 序列导出、.out 选择和 CSV 转换输出路径。
   - 如果路径权限不足，请将软件解压到桌面或用户文档目录后运行。

Author: ZYY
Email: zhangyiye1860@163.com
