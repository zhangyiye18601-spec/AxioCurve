LineAnimation Windows 使用说明
=============================

1. 如果电脑已安装 MATLAB Runtime R2024a：
   直接双击 LineAnimation.exe 即可运行。

2. 如果首次运行提示缺少 MATLAB Runtime：
   先双击 MyAppInstaller_web.exe，按提示安装运行环境；安装完成后再运行 LineAnimation.exe。

3. 基本使用流程：
   - 点击“选择数据文件”导入 CSV。
   - 在左侧数据表中勾选一个 X 列，可分别勾选 Y左 和 Y右 曲线。
   - 点击“静态预览”检查坐标轴、图例、颜色和字体。
   - 设置导出宽高、DPI、动画间隔和导出格式。
   - 点击“导出选定格式”输出 GIF、MP4、PNG 序列或静态图片。

4. 注意事项：
   - GIF/MP4/PNG序列会按照动画间隔抽帧。
   - PNG/JPG/TIF 单图会导出完整曲线。
   - 如果路径权限不足，请将软件解压到桌面或用户文档目录后运行。

Author: ZYY
Email: zhangyiye1860@163.com
